class ProductWizardRepository:
    pass