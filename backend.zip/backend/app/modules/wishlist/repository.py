from app.extensions import db
from .models import WishlistItem


class WishlistRepository:

    @staticmethod
    def get(account_id):

        return WishlistItem.query.filter_by(
            account_id=account_id
        ).all()

    @staticmethod
    def get_item(account_id, product_id):

        return WishlistItem.query.filter_by(
            account_id=account_id,
            product_id=product_id,
        ).first()

    @staticmethod
    def create(item):

        db.session.add(item)
        db.session.commit()

        return item

    @staticmethod
    def delete(item):

        db.session.delete(item)
        db.session.commit()